package com.mit.demo;

/**
 * Created by pruebas on 21/10/15.
 */
public class Utils {
/*
    public static String cifrarXMLA(String xmla){
        String xmla = AESEncriptacion.cifrar(generaXMLA(), Hex.decodeHex(Constants.SEED.toCharArray()), "CBC", "PKCS5Padding", new Base64());//.toUpperCase();
        Log.i("XMLA BASE 64", xmla);
        xmla = String.valueOf(Hex.encodeHex(xmla.getBytes()));
        Log.i("XMLA HEX", xmla);
        String url2= "?id_company=" + Constants.idCommerce + "&xmlm=" + Constants.XMLM + "&xmla=" + xmla;
    }

    public String generaXMLA(){
        return "<xml>" +
                "<tpPago>C</tpPago>" +
                "<amount>2000</amount>" +
                "<urlResponse>" + Constants.URL_RESPOSE + "</urlResponse>" +
                "<referencia>TEST_0001</referencia>" +
                "<moneda>MXN</moneda>" +
                "<date_hour>2015-10-20T17:49:24-05:00<date_hour>";
    }*/
}
