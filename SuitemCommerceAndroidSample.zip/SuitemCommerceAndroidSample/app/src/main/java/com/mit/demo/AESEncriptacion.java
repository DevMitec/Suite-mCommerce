package com.mit.demo;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Properties;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.BinaryDecoder;
import org.apache.commons.codec.BinaryEncoder;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

public class AESEncriptacion {
	private static final String ALGORITMO = "AES"; //AES/ECB/PKCS5Padding
	private static final int LONGITUD = 128;
	private static final String CODIFICACION = "UTF-8";	
	private static final String MODE = "CBC";

	public static String  generaKey() throws Exception {
		String resp;
		KeyGenerator kgen = KeyGenerator.getInstance(ALGORITMO);
		kgen.init(LONGITUD);
		SecretKey skey = kgen.generateKey();			
		resp = new String(Hex.encodeHex(skey.getEncoded()));
		return resp;
	}

	public static String encripta(String cadena, String llave) throws NoSuchAlgorithmException,
			NoSuchPaddingException, InvalidKeyException,
			IllegalBlockSizeException, BadPaddingException,
			UnsupportedEncodingException, DecoderException {
		
		byte[] raw = Hex.decodeHex(llave.toCharArray());
		SecretKeySpec skeySpec = new SecretKeySpec(raw, ALGORITMO);
		Cipher cipher = Cipher.getInstance(ALGORITMO);
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		byte[] encrypted = cipher.doFinal(cadena.getBytes(CODIFICACION));
		char[] encriptado = Hex.encodeHex(encrypted);
		return new String (encriptado);
	}

	public static String cifrar(String cadena, byte[] llave, String mode,
			String padding, BinaryEncoder encoder)
			throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException,
			BadPaddingException, DecoderException, IOException,
			EncoderException {

		SecretKeySpec skeySpec = new SecretKeySpec(llave, ALGORITMO);

		String transformation = loadTransformation(mode, padding);

		Cipher cipher = Cipher.getInstance(transformation);
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		byte[] encrypted = cipher.doFinal(cadena.getBytes(CODIFICACION));

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		if (cipher.getIV() != null) {
			outputStream.write(cipher.getIV());
		}
		outputStream.write(encrypted);
		encrypted = outputStream.toByteArray();
		outputStream.close();

		encrypted = encoder.encode(encrypted);
		return new String(encrypted);
	}

	public static String desencriptar(String encriptado, String llave) throws InvalidKeyException,
			IllegalBlockSizeException, BadPaddingException,
			UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, DecoderException {
		byte[] raw = Hex.decodeHex(llave.toCharArray());
		SecretKeySpec skeySpec = new SecretKeySpec(raw, ALGORITMO);
		Cipher cipher = Cipher.getInstance(ALGORITMO);		
		cipher.init(Cipher.DECRYPT_MODE, skeySpec);
		byte[] original = cipher.doFinal( Hex.decodeHex(encriptado.toCharArray()));
		String originalString = new String(original);
		return originalString;
	}	

	public static String descifrar(String encriptado, byte[] llave,
			String mode, String padding, BinaryDecoder decoder)
			throws InvalidKeyException, IllegalBlockSizeException,
			BadPaddingException, UnsupportedEncodingException,
			NoSuchAlgorithmException, NoSuchPaddingException, DecoderException,
			InvalidAlgorithmParameterException {
		SecretKeySpec skeySpec = new SecretKeySpec(llave, ALGORITMO);

		String transformation = loadTransformation(mode, padding);

		byte[] initialData = decoder.decode(encriptado.getBytes());

		IvParameterSpec ivSpecs = null;
		if (MODE.equalsIgnoreCase(mode)) {
			byte[] iv = Arrays.copyOfRange(initialData, 0, 16);
			ivSpecs = new IvParameterSpec(iv);
			initialData = Arrays.copyOfRange( initialData, 16, initialData.length );
		}

		Cipher cipher = Cipher.getInstance(transformation);
		cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivSpecs);
		byte[] original = cipher.doFinal(initialData);
		String originalString = new String(original);
		return originalString;
	}

	private static String loadTransformation(String mode, String padding) {
		String transformation = ALGORITMO;
		transformation += mode == null ? "/ECB" : "/" + mode;
		transformation += padding == null ? "/PKCS5PADDING" : "/" + padding;
		return transformation;
	}
	
	public static String encriptaTwoKeys(String cadena, Properties props, String mode, String padding) throws NoSuchAlgorithmException, NoSuchPaddingException,
	InvalidKeyException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, DecoderException, org.apache.commons.codec.EncoderException {

		String llave = obtenerLLave(props);
		byte[] raw = Hex.decodeHex(llave.toCharArray());
		String result = null;
		try {
			result = cifrar(cadena, raw, mode, padding, new Base64());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (EncoderException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public static String desencriptarTwoKeys(String encriptado, Properties props, String mode, String padding) throws InvalidKeyException, IllegalBlockSizeException,
	BadPaddingException, UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, DecoderException {
		String llave = obtenerLLave(props);
		byte[] raw = Hex.decodeHex(llave.toCharArray());
		
		String originalString = null;
		try {
			originalString = descifrar(encriptado, raw, mode, padding, new Base64());
		} catch (InvalidAlgorithmParameterException e) {
			e.printStackTrace();
		}
		return originalString;
	}
	
	 public static String obtenerLLave(Properties props) {
			String llave_Decrypted="";
		 	
		 	String key_a = leerficheros5(props.getProperty("ruta.A") + props.getProperty("key.A"));//"KeyA_PGS");
		 	String key_b = leerficheros5(props.getProperty("ruta.B") + props.getProperty("key.B"));//"KeyA_PGS");

			//procedemos a dencriptar la llave A de 128 bits  con la llave B de 256 bits
			try {
				llave_Decrypted = desencriptarBytes(key_a, key_b);
			} catch (InvalidKeyException e)          { e.printStackTrace();
			} catch (IllegalBlockSizeException e)    { e.printStackTrace();
			} catch (BadPaddingException e)          { e.printStackTrace();
			} catch (UnsupportedEncodingException e) { e.printStackTrace();
			} catch (NoSuchAlgorithmException e)     { e.printStackTrace();
			} catch (NoSuchPaddingException e)       { e.printStackTrace();
			} catch (DecoderException e)             { e.printStackTrace();
		    }
		 
	    	return llave_Decrypted;
		 
	    }
	
	 public static String leerficheros5 (String filename) {
		 	String salida ="";
			File file = new File(filename);
			FileInputStream fin = null;
			try {
				fin = new FileInputStream(file);

				byte fileContent[] = new byte[(int)file.length()];
				
				// Reads up to certain bytes of data from this input stream into an array of bytes.
				fin.read(fileContent);
				//create string from byte array
				String s = new String(fileContent);
				salida = new String(Hex.encodeHex(fileContent));
			}
			catch (FileNotFoundException e) {
				System.out.println("File not found" + e);
			}
			catch (IOException ioe) {
				System.out.println("Exception while reading file " + ioe);
			}
			finally {
				// close the streams using close method
				try {
					if (fin != null) {
						fin.close();
					}
				}
				catch (IOException ioe) {
					System.out.println("Error while closing stream: " + ioe);
				}
			}
			return salida;
		}
	 
	 public static String desencriptarBytes(String encriptado, String llave) throws InvalidKeyException, IllegalBlockSizeException,
		BadPaddingException, UnsupportedEncodingException, NoSuchAlgorithmException, NoSuchPaddingException, DecoderException {


		byte[] raw = Hex.decodeHex(llave.toCharArray());
		
		String originalString = null;
		try {
			originalString = descifrar(encriptado, raw, MODE, null, new Hex());
		} catch (InvalidAlgorithmParameterException e) {
			e.printStackTrace();
		}
		return originalString;
	 }
		
}
