package com.mit.demo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;

public class FormActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(getString(R.string.app_name));


        final EditText editTextMonto = (EditText) findViewById(R.id.editTextMonto);
        final EditText editTextReferencia = (EditText) findViewById(R.id.editTextReferencia);

        findViewById(R.id.buttonPagar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i =  new Intent(FormActivity.this, MainActivity.class);
                i.putExtra(MainActivity.EXTRA_AMOUNT, editTextMonto.getText().toString());
                i.putExtra(MainActivity.EXTRA_REFERENCE, editTextReferencia.getText().toString());
                startActivity(i);
            }
        });
    }


}
