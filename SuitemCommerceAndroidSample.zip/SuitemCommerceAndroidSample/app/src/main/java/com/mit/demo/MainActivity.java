package com.mit.demo;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

public class MainActivity extends AppCompatActivity {

    public static String EXTRA_AMOUNT = "amount";
    public static String EXTRA_REFERENCE = "reference";

    public int ENVIRONMENT = 0;
    public final int ENVIRONMENT_DEV = 0;
    public final int ENVIRONMENT_QA = 1;
    public final int ENVIRONMENT_PROD = 2;

    WebView webView;
    boolean dev = true;
    boolean processComplete = false;

    String amount;
    String reference;

    @JavascriptInterface
    public void onData(String value) {
        String respuestaEncriptada = value.substring(
                value.indexOf("<td align=\"right\">Respuesta Encriptada: </td>"),
                value.indexOf("<td align=\"right\">Respuesta Correo : </td>"));
        respuestaEncriptada = respuestaEncriptada.substring(
                respuestaEncriptada.indexOf("<td align=\"left\"><b>") + "<td align=\"left\"><b>".length(),
                respuestaEncriptada.indexOf("</b> </td>"));
        if(respuestaEncriptada!=null && !respuestaEncriptada.equals("")) {
            processComplete = true;
            Log.e("respuestaEncriptada", respuestaEncriptada);
            final String response = getText(respuestaEncriptada);
            Log.e("response", response);
            webView.post(new Runnable() {
                @Override
                public void run() {
                    webView.loadUrl("javascript:alert('" + response + "');");
                }
            });
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        readEnvironment();
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(getString(R.string.app_name) + " [" + getEnvironmentText() + "]");

        processComplete = false;
        webView = (WebView) findViewById(R.id.webView);
        webView.setWebChromeClient(new myWebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.addJavascriptInterface(this, "android");

        amount = getIntent().getStringExtra(EXTRA_AMOUNT);
        reference = getIntent().getStringExtra(EXTRA_REFERENCE);
        Log.e("referecnia",reference);

        goHome();
    }

    public void goHome(){
        getSupportActionBar().setTitle(getString(R.string.app_name) + " [" + getEnvironmentText() + "]");
        try {

            byte[] llave = new byte[0];
            String idCompany = "";
            String xmlm = "";
            String host = "";

            switch (ENVIRONMENT){
                case ENVIRONMENT_DEV:
                    llave = Hex.decodeHex(Constants.DEV_SEED.toCharArray());
                    idCompany = Constants.DEV_idCommerce;
                    xmlm = Constants.DEV_XMLM;
                    host = Constants.URL_DEV;
                    break;
                case ENVIRONMENT_QA:
                    llave = Hex.decodeHex(Constants.QA_SEED.toCharArray());
                    idCompany = Constants.QA_idCommerce;
                    xmlm = Constants.QA_XMLM;
                    host = Constants.URL_QA;
                    break;
                case ENVIRONMENT_PROD:
                    llave = Hex.decodeHex(Constants.PROD_SEED.toCharArray());
                    idCompany = Constants.PROD_idCommerce;
                    xmlm = Constants.PROD_XMLM;
                    host = Constants.URL_PROD;
                    break;
            }

            String xmla = AESEncriptacion.cifrar(generaXMLA(), llave, "CBC", "PKCS5Padding", new Base64());
            xmla = String.valueOf(Hex.encodeHex(xmla.getBytes()));
            String parameters= "?id_company=" + idCompany + "&xmlm=" +xmlm + "&xmla=" + xmla;
            Log.e("URL", host + parameters);
            webView.loadUrl(host + parameters);
        } catch (Exception e) {
            Log.e("Exception***", e.getMessage());
            e.printStackTrace();
        }
    }

    public String getText(String data){
        String result = data;
        try {
            data = new String(Hex.decodeHex(data.toCharArray()));
            result = AESEncriptacion.descifrar(data, Hex.decodeHex((dev?Constants.DEV_SEED:Constants.QA_SEED).toCharArray()), "CBC", "PKCS5Padding", new Base64());
        }catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }

    class myWebViewClient extends WebChromeClient{

        @Override
        public void onProgressChanged(WebView view, int progress) {
            if (progress == 100 && !processComplete) {
                webView.loadUrl("javascript:var x = document.documentElement.innerHTML;android.onData(x)");
            }
        }
    }

    public String generaXMLA(){
        return "<xml>" +
                    "<tpPago>C</tpPago>" +
                    "<amount>" + amount + "</amount>" +
                    "<urlResponse>" + Constants.URL_RESPOSE + "</urlResponse>" +
                    "<referencia>" + reference + "</referencia>" +
                    "<moneda>MXN</moneda>" +
                    "<date_hour>2015-10-20T17:49:24-05:00</date_hour>";
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_dev) {
            ENVIRONMENT = ENVIRONMENT_DEV;
            writeEnvironment();
            goHome();
            return true;
        }

        if (id == R.id.action_qa) {
            ENVIRONMENT = ENVIRONMENT_QA;
            writeEnvironment();
            goHome();
            return true;
        }

        if (id == R.id.action_prod) {
            ENVIRONMENT = ENVIRONMENT_PROD;
            writeEnvironment();
            goHome();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void writeEnvironment(){
        SharedPreferences sp = getSharedPreferences("demowp", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt("environment", ENVIRONMENT);
        editor.apply();
        editor.commit();
    }

    public void readEnvironment(){
        SharedPreferences sp = getSharedPreferences("demowp", MODE_PRIVATE);
        ENVIRONMENT = sp.getInt("environment", 0);
    }

    public String getEnvironmentText(){
        switch (ENVIRONMENT){
            case ENVIRONMENT_DEV:
                return "DEV";
            case ENVIRONMENT_QA:
                return "QA";
            case ENVIRONMENT_PROD:
                return "PROD";
        }
        return "";
    }
}
